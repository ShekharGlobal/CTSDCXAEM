package com.cts.details;

import java.time.LocalDate;

public class Employee {
	private Integer id;
	private String name;
	private String gender;
	private LocalDate DateOfBirth;
	private boolean fulltimeEmployement;
	private String department;
	private Integer salary;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public LocalDate getDateOfBirth() {
		return DateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		DateOfBirth = dateOfBirth;
	}
	public boolean isFulltimeEmployement() {
		return fulltimeEmployement;
	}
	public void setFulltimeEmployement(boolean fulltimeEmployement) {
		this.fulltimeEmployement = fulltimeEmployement;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public Integer getSalary() {
		return salary;
	}
	public void setSalary(Integer salary) {
		this.salary = salary;
	}
	
	public Employee(Integer id, String name, String gender, LocalDate dateOfBirth, boolean fulltimeEmployement,
			String department, Integer salary) {
		super();
		this.id = id;
		this.name = name;
		this.gender = gender;
		DateOfBirth = dateOfBirth;
		this.fulltimeEmployement = fulltimeEmployement;
		this.department = department;
		this.salary = salary;
	}
	public Employee() {
		super();
	}
	
	}
	