<%@ page contentType="text/html;charset=UTF-8"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
 
<html>
<body>
 
	<h2>Employee Details Form</h2>
<form action="Employverify" method="post">
 
	Employee Id:
	<input type="text" name="id" value="${emp.id}">
	<br>
	<br> Employee Name:
	<input type="text" name="name" value="${emp.name}">
	<br>
	<br> Gender:
	<input type="radio" name="gender" value="Male"
		<c:if test="${emp.gender=='Male'}">checked</c:if>> Male
 
	<input type="radio" name="gender" value="Female"
		<c:if test="${emp.gender=='Female'}">checked</c:if>> Female
	<br>
	<br>
	<label for="dateOfBirth">Date Of Birth:</label>
	<input type="date" id="dateOfBirth" name="dateOfBirth"
		value="${emp.dateOfBirth}" />
 
	<br>
	<br> Full-time Employee:
	<input type="checkbox" name="fulltime" value="true"
		<c:if test="${emp.fulltimeEmployement}">checked</c:if>>
	<br>
	<br> Department:
	<select name="department">
		<c:forEach var="depart" items="${departments}">
			<option value="${depart}"
				<c:if test="${depart == emp.department}">selected</c:if>>${depart}</option>
		</c:forEach>
	</select>
	<br>
	<br> Salary:
	<input type="text" name="salary" value="${emp.salary}">
	<br>
	<br>
 
	<input type="submit" value="Submit">
</form>
</body>
</html>
 
 