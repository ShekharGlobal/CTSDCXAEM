<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
  
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
   <h2>Employee Details Form</h2>
    <form action="EmployeeDetailsServlet" method="post">
        
        Employee Id:
        <input type="text" name="id" value="<c:out value='${employee.id}'/>" /><br/>
 
        Employee Name:
        <input type="text" name="name" value="<c:out value='${employee.name}'/>" /><br/>
 
        Gender:
        <select name="gender">
            <option value="Male" <c:if test="${employee.gender == 'Male'}">selected</c:if>>Male</option>
            <option value="Female" <c:if test="${employee.gender == 'Female'}">selected</c:if>>Female</option>
            <option value="Other" <c:if test="${employee.gender == 'Other'}">selected</c:if>>Other</option>
        </select><br/>
 
        Date of Birth:
        <input type="date" name="dob" value="<c:out value='${employee.dob}'/>" /><br/>
 
        Full Time Employee:
        <input type="checkbox" name="fullTime" <c:if test="${employee.fullTime}">checked</c:if> /><br/>
 
		Salary:
		<input type="text" name="salary" value="<c:out value='${employee.salary}'/>" /><br/>
		
        Department:
        <select name="department">
            <option value="IT" <c:if test="${employee.department == 'IT'}">selected</c:if>>IT</option>
            <option value="HR" <c:if test="${employee.department == 'HR'}">selected</c:if>>HR</option>
            <option value="Finance" <c:if test="${employee.department == 'Finance'}">selected</c:if>>Finance</option>
            <option value="Sales" <c:if test="${employee.department == 'Sales'}">selected</c:if>>Sales</option>
        </select><br/>
 
        <input type="submit" value="Update"/>
    </form>
</body>
</html>