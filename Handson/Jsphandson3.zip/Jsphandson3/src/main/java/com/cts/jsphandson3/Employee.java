package com.cts.jsphandson3;

import java.time.LocalDate;

public class Employee {
	    private String id;
		private String name;
		private String gender;
		private LocalDate dob;
		private boolean fullTime;
		private String department;
		private double salary;
		
		public Employee()
		{
			super();
		}
		public Employee(String id, String name, String gender, LocalDate dob, boolean fulltime2, String department, double salary) {
			super();
			this.id = id;
			this.name = name;
			this.gender = gender;
			this.dob = dob;
			this.fullTime = fulltime2;
			this.department = department;
			this.salary = salary;
		}
	 
		public String getId() {
			return id;
		}
	 
		public void setId(String id) {
			this.id = id;
		}
	 
		public String getName() {
			return name;
		}
	 
		public void setName(String name) {
			this.name = name;
		}
	 
		public String getGender() {
			return gender;
		}
	 
		public void setGender(String gender) {
			this.gender = gender;
		}
	 
		public LocalDate getDob() {
			return dob;
		}
	 
		public void setDob(LocalDate string) {
			this.dob = string;
		}
	 
		public boolean isFullTime() {
			return fullTime;
		}
	 
		public void setFullTime(boolean fullTime) {
			this.fullTime = fullTime;
		}
	 
		public String getDepartment() {
			return department;
		}
	 
		public void setDepartment(String department) {
			this.department = department;
		}
		public double getSalary() {
			return salary;
		}
		public void setSalary(double salary) {
			this.salary = salary;
		}
	 

}
