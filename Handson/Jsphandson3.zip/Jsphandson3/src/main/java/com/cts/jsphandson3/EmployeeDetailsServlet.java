package com.cts.jsphandson3;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.time.LocalDate;

/**
 * Servlet implementation class EmployeeDetailsServlet
 */
@WebServlet("/EmployeeDetailsServlet")
public class EmployeeDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeDetailsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		HttpSession session = request.getSession();
		Employee emp = (Employee) session.getAttribute("employee");
		if (emp == null) {
			emp = new Employee();
			emp.setId("1");
			emp.setName("jashu");
			emp.setGender("Male");
			
			LocalDate dob = LocalDate.parse("2003-10-05");
			emp.setDob(dob);	
			
			emp.setDepartment("IT");
			emp.setFullTime(true);
			emp.setSalary(20000.0);
			session.setAttribute("employee", emp);
			}
		
			String id = request.getParameter("id");
			if (id != null) {
				emp.setId(id);
				emp.setName(request.getParameter("name"));
				emp.setGender(request.getParameter("gender"));
				
				LocalDate dobStr =LocalDate.parse( request.getParameter("dob"));
				java.sql.Date dob = null;
				if (dobStr != null ) {
					
				emp.setDob(dobStr);
				}
				
				emp.setDepartment(request.getParameter("department"));
				emp.setFullTime(request.getParameter("fullTime") != null);
				String salaryStr = request.getParameter("salary");
				if (salaryStr != null && !salaryStr.isEmpty()) {
				    emp.setSalary(Double.parseDouble(salaryStr));
				}
				session.setAttribute("employee", emp);
				request.setAttribute("employee", emp);
				RequestDispatcher dispatcher = request.getRequestDispatcher("update.jsp");
				dispatcher.forward(request, response);
				return;
				}
			request.setAttribute("employee", emp);
			RequestDispatcher dispatcher = request.getRequestDispatcher("display.jsp");
			dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
