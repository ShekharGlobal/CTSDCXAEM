package com.hcl.collections;

import java.util.SortedMap;
import java.util.TreeMap;

public class Col {

	public static void main(String[] args) {
		
	//	Stack<String>a1= new Stack<String>();
		
		//SortedSet<String> s1= new TreeSet<String>();
		
		SortedMap<Integer,String>m1= new TreeMap<Integer,String>();
		
		m1.put(4, "Australia");
		m1.put(1, "India");
		m1.put(2, "South Africa");
		m1.put(5, "India");
		m1.put(null, "Japan");
		
		System.out.println(m1);
		
		//s1.addFirst("Tomato");
		//s1.addLast("Potato");
		//s1.add(2, "Cabbage");
		
		//a1.removeFirst();
		//a1.removeLast();
		//a1.remove(4);
		//s1.push("Grapes");
		//s1.pop();
		//System.out.println(a1.capacity());
		
		/*
		 * Iterator<String>i1= s1.iterator(); while(i1.hasNext()) {
		 * System.out.println(i1.next()); }
		 */
		
				
	}

}
